Latest changes
===============

Release 0.1.0
--------------
